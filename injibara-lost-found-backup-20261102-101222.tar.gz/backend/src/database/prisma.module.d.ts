export {};
//# sourceMappingURL=prisma.module.d.ts.map