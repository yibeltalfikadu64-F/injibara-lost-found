export {};
//# sourceMappingURL=items.controller.d.ts.map