export {};
//# sourceMappingURL=register.dto.d.ts.map