export {};
//# sourceMappingURL=admin.module.d.ts.map